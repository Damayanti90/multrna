

univ=[]
mir={}
count=0
fs=open(r"miRNA_genes.txt","r")
for line in fs:
       count+=1
       x=line.split("`")
       y=x[1].split(",")
       z={i for i in y}
       mir[x[0]]=z
       univ+=y
fs.close()
univ=list(set(univ))
print(len(univ),len(mir.keys()))








go_final={}
fs=open(r"miRNA_genes.txt","r")
for line in fs:
    x=line.split("`")
    y=x[1].split(",")
    z={i for i in y}
    go_final[x[0]]=z
    univ+=y
fs.close()
print(len(go_final.keys()))
univ=list(set(univ))
print(len(univ))





import numpy as np
import pandas as pd
from scipy.stats import hypergeom
from statsmodels.stats.multitest import multipletests


def mir_mir(mir, go, univ):

    N = len(univ)
    results = []
    ccc=0
    for mirna, targ in mir.items():
        ccc+=1
        print("miRNAs covered",ccc)
        T_m = targ.intersection(univ)
        n = len(T_m)
        if n == 0:
            continue
        for go_id, go_genes in go.items():
            G_g = go_genes.intersection(univ)
            M = len(G_g)
            if M == 0:
                continue
            if mirna==go_id:
               continue
            common=T_m.intersection(G_g)
            k=len(common) 
            if k > 0:
                tot = len(T_m.union(G_g))
                jacc = k / tot if tot > 0 else 0
                p_val = hypergeom.sf(k - 1, N, M, n)
                results.append({"miRNA": mirna, "GO_ID": go_id, "Intersection_Count": k, "Shared_Genes": ",".join(map(str, common)), "Jaccard_Similarity": jacc, "P_Value": p_val,})
    if not results:
        return pd.DataFrame()
    df = pd.DataFrame(results)
    _, p_adj, _, _ = multipletests(df["P_Value"], alpha=0.05, method="fdr_bh")
    df["FDR_Adjusted_P"] = p_adj
    df = df.sort_values(by=["FDR_Adjusted_P", "Jaccard_Similarity"], ascending=[True, False])
    return df



if __name__ == "__main__":

    op = mir_mir(mir, go_final, univ) 
    print(op.to_string(index=False))


op.to_csv("mir_mir_all.csv", index=False)
