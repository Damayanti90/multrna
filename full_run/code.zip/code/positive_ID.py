

count=0
ft=open(r"positive_ID_mir_go_dis_whole.txt","w")
fs=open(r"miRNA_miRNA_whole.txt","r")
for line in fs:
    count+=1
    ft.write(line.strip())
    ft.write("\n")
fs.close()
print("mir-mir",count)

fs=open(r"miRNA_GO_jaccard_whole.txt","r")
for line in fs:
    count+=1
    ft.write(line.strip())
    ft.write("\n")
fs.close()
print(count)

print("mir-mir+mir-go",count)

fs=open(r"miRNA_disease.txt","r")
for line in fs:
    count+=1
    ft.write(line.strip())
    ft.write("\n")
fs.close()


ft.close()
print("mir-mir+mir-go+mir-dis",count)




