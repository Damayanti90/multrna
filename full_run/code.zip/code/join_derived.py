

count=0
c=0
import re
p=[]
mir_dic={}
mir_line={}
lines=[]
fs=open(r"mir_go_all.csv","r")
for line in fs:
    count+=1
    x=line.split(",")
    if count>1:
       s=x[0]+"`"+x[1]+"`"
       s=s.strip()
       lines.append(s)
       p.append(float(x[-2].strip()))
       if x[0] in mir_dic.keys():
          temp=mir_dic[x[0]]
          temp.append(float(x[-2].strip()))
          mir_dic[x[0]]=temp
          ttt=mir_line[x[0]]
          ttt.append(line.strip())
          mir_line[x[0]]=ttt
       else:
          mir_dic[x[0]]=[float(x[-2].strip())]
          mir_line[x[0]]=[line.strip()]
       if float(x[-3].strip())>=0.0002807017543859:
          c+=1
    if count<=10:
       print(line)
fs.close()
print(c,min(p),max(p))


import statsmodels.stats.multitest as multitest


reject, fdr_p_values, alphacSidak, alphacBonf = multitest.multipletests(p, method='fdr_bh')


print(len([i for i in fdr_p_values if i<0.05]))
print("\n")
print(max(fdr_p_values),min(fdr_p_values))

count=0
fs=open(r"miRNA_GO_jaccard_whole.txt","w")
for line,p_val in zip(lines,fdr_p_values):
    if p_val>=0.05:
       continue
    count+=1
    fs.write(line.strip())
    fs.write("\n")
fs.close()
print(count)

count=0
c=0
import re
p=[]
mir_dic={}
mir_line={}
lines=[]
fs=open(r"mir_mir_all.csv","r")
for line in fs:
    count+=1
    x=line.split(",")
    if count>1:
       p.append(float(x[-2].strip()))
       s=x[0]+"`"+x[1]+"`"
       s=s.strip()
       lines.append(s)
       if x[0] in mir_dic.keys():
          temp=mir_dic[x[0]]
          temp.append(float(x[-2].strip()))
          mir_dic[x[0]]=temp
          ttt=mir_line[x[0]]
          ttt.append(line.strip())
          mir_line[x[0]]=ttt
       else:
          mir_dic[x[0]]=[float(x[-2].strip())]
          mir_line[x[0]]=[line.strip()]
       if float(x[-3].strip())>=0.0002807017543859:
          c+=1
    if count<=10:
       print(line)
fs.close()
print(c,min(p),max(p))

import statsmodels.stats.multitest as multitest

reject, fdr_p_values, alphacSidak, alphacBonf = multitest.multipletests(p, method='fdr_bh')


print(len([i for i in fdr_p_values if i<0.05]))
print("\n")
print(max(fdr_p_values),min(fdr_p_values))

f_lines=[]
symb="`"
for line,p_val in zip(lines,fdr_p_values):
    if p_val>=0.05:
       continue
    x=line.split(symb)
    t=x[1]+symb+x[0]+symb
    if line not in f_lines and t not in f_lines:
       f_lines.append(line)
print(len(f_lines))



count=0
fs=open(r"miRNA_miRNA_whole.txt","w")
for line in f_lines:
    count+=1
    fs.write(line.strip())
    fs.write("\n")
fs.close()
print(count)


