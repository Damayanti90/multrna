

symb="`"
l=[]
node_mir=[]
node_go=[]
node_dis=[]
ft=open(r"merged_embeddings_mir_go_dis_BiGRU.txt","r")
for line in ft:
    x=line.split(symb)
    if x[0].startswith("hsa-miR-155-5p"):
       print(x[0])
       node_mir.append(x[0])
    
ft.close()



def leaf(file_path):
    all_terms = set()
    parent_terms = set()
    is_obsolete = False
    current_term = None
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()            
            if line == '[Term]':
                if current_term and not is_obsolete:
                    all_terms.add(current_term)
                current_term = None
                is_obsolete = False
            elif line == '[Typedef]' or line == '[Instance]':
                current_term = None  
            elif line.startswith('id: ') and line.startswith('id: GO:'):
                temp=line[4:].split()
                current_term=temp[0].strip()
            elif line.startswith('is_a: ') and current_term:                
                temp=line[6:].split('!')
                tempa=temp[0].strip().split()
                parent_terms.add(tempa[0])
            elif line == 'is_obsolete: true':
                is_obsolete = True        
        if current_term and not is_obsolete:
            all_terms.add(current_term)    
    leaves = sorted(list(all_terms - parent_terms))
    return leaves

leaves = leaf('go-basic.obo')
print("leaves", leaves)

go_active=[]
fs=open(r"go_genes.txt","r")
for line in fs:
    x=line.split("`")
    go_active.append(x[0])
fs.close()
print(len(go_active))

active_leaves=set(go_active). intersection (set(leaves))
active_leaves=list(active_leaves)
print(len(active_leaves))

from goatools import obo_parser
import os

obo_file = 'go-basic.obo'
go = obo_parser.GODag(obo_file)


bp_terms = []
for go_id, term in go.items():
    if term.namespace == 'biological_process':
        bp_terms.append(go_id)

print(len(bp_terms))


for t in bp_terms[:10]:
    print(t)

from goatools import obo_parser
import os

obo_file = 'go-basic.obo'
go = obo_parser.GODag(obo_file)



for go_id, term in go.items():
    if term.namespace == 'molecular_function':
        bp_terms.append(go_id)

print(len(bp_terms))


for t in bp_terms[:10]:
    print(t)

bp_mf_leaves=set(active_leaves).intersection(set(bp_terms))
bp_mf_leaves=list(bp_mf_leaves)
print(len(bp_mf_leaves))

excluded=[]
fs=open(r"total_ID_mgd_BiGRU_jaccard.txt","r")
for line in fs:
    excluded.append(line.strip())
fs.close()



fs=open(r"pos_test_data.txt","r")
for line in fs:
    excluded.append(line.strip())
fs.close()

print(len(excluded))

blind_data=[]
for a in node_mir:
    for b in bp_mf_leaves:
        s=a+"`"+b+"`"
        blind_data.append(s)
print(len(blind_data))

blind_data=set(blind_data). difference (set(excluded))
blind_data=list(blind_data)

len(blind_data)

count=0
fa=open(r"blind_data_jaccard_155.txt","w")
for line in blind_data:
    count+=1
    fa.write(line.strip())
    fa.write("\n")
fa.close()
print(count)


