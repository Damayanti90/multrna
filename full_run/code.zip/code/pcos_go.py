
pcos_enriched=[]
count=0
import re
fs=open(r"pcos_bp.txt","r")
for line in fs:
    count+=1
    if count>=13:
       x=re.split("\t",line)
       y=x[0].split("(")
       z=y[-1][:-1]
       pcos_enriched.append(z)
    if count<=50:
      print(count,line)
      if count>=13:
         print(x)
         print(z)
fs.close()
print(count)



count=0
import re
fs=open(r"pcos_mf.txt","r")
for line in fs:
    count+=1
    if count>=13:
       x=re.split("\t",line)
       y=x[0].split("(")
       z=y[-1][:-1]
       pcos_enriched.append(z)
    if count<=50:
      print(count,line)
      if count>=13:
         print(x)
         print(z)
fs.close()
print(count)
print(len(pcos_enriched))

anov_pcos_enriched=[]
count=0
import re
fs=open(r"anov_pcos_bp.txt","r")
for line in fs:
    count+=1
    if count>=13:
       x=re.split("\t",line)
       y=x[0].split("(")
       z=y[-1][:-1]
       anov_pcos_enriched.append(z)
    if count<=50:
      print(count,line)
      if count>=13:
         print(x)
         print(z)
fs.close()
print(count)



count=0
import re
fs=open(r"anov_pcos_mf.txt","r")
for line in fs:
    count+=1
    if count>=13:
       x=re.split("\t",line)
       y=x[0].split("(")
       z=y[-1][:-1]
       anov_pcos_enriched.append(z)
    if count<=50:
      print(count,line)
      if count>=13:
         print(x)
         print(z)
fs.close()
print(count)
print(len(anov_pcos_enriched))

diabetes_pcos_enriched=[]
count=0
import re
fs=open(r"diabetes_pcos_bp.txt","r")
for line in fs:
    count+=1
    if count>=13:
       x=re.split("\t",line)
       y=x[0].split("(")
       z=y[-1][:-1]
       diabetes_pcos_enriched.append(z)
    if count<=50:
      print(count,line)
      if count>=13:
         print(x)
         print(z)
fs.close()
print(count)



count=0
import re
fs=open(r"diabetes_pcos_mf.txt","r")
for line in fs:
    count+=1
    if count>=13:
       x=re.split("\t",line)
       y=x[0].split("(")
       z=y[-1][:-1]
       diabetes_pcos_enriched.append(z)
    if count<=50:
      print(count,line)
      if count>=13:
         print(x)
         print(z)
fs.close()
print(count)
print(len(diabetes_pcos_enriched))

hyperandrogenism_pcos_enriched=[]
count=0
import re
fs=open(r"hyperandrogenism_pcos_bp.txt","r")
for line in fs:
    count+=1
    if count>=13:
       x=re.split("\t",line)
       y=x[0].split("(")
       z=y[-1][:-1]
       hyperandrogenism_pcos_enriched.append(z)
    if count<=50:
      print(count,line)
      if count>=13:
         print(x)
         print(z)
fs.close()
print(count)



count=0
import re
fs=open(r"hyperandrogenism_pcos_mf.txt","r")
for line in fs:
    count+=1
    if count>=13:
       x=re.split("\t",line)
       y=x[0].split("(")
       z=y[-1][:-1]
       hyperandrogenism_pcos_enriched.append(z)
    if count<=50:
      print(count,line)
      if count>=13:
         print(x)
         print(z)
fs.close()
print(count)
print(len(hyperandrogenism_pcos_enriched))

count=0
predicted=[]
fs=open(r"predicted_associations.txt","r")
for line in fs:
    count+=1
    x=line.split("`")
    if float(x[4].strip())>=0.5:
       predicted.append(x[1].strip())
    if count<=10:
       print(line)
fs.close()
print(count)
print(len(predicted))

print("pcos",len(set(predicted).intersection(set(pcos_enriched))))

print("anov+pcos",len(set(predicted).intersection(set(anov_pcos_enriched))))

print("dia+pcos",len(set(predicted).intersection(set(diabetes_pcos_enriched))))

print("hypo+pcos",len(set(predicted).intersection(set(hyperandrogenism_pcos_enriched))))
