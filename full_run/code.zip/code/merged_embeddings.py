
symb="`"
go_ids=[]
fa=open(r"go_ids.txt","r")
for line in fa:
    go_ids.append(line.strip())
fa.close()
print(len(go_ids))



counter=0
l=[]
fv=open(r"SBERT_embeddings_PCA_AE_BiGRU_PCA_AE_imp.txt","w")
fs=open(r"SBERT_embeddings_PCA_AE_BiGRU_PCA_AE.txt","r")
for line in fs:
    x=line.split(symb)
    y=line.split(symb,1)
    s=go_ids[counter]+symb+y[1].strip()
    fv.write(s.strip())
    fv.write("\n")
    counter+=1
    if counter<=10:
       print(s)
    tt=s.split(symb)
    l.append(len(tt))
fs.close()
fv.close()

symb="`"
l=[]
node_mir=[]
node_go=[]
node_dis=[]
ft=open(r"merged_embeddings_mir_go_dis_BiGRU.txt","w")
fs=open(r"Rinalmo_embeddings_PCA_AE_BiGRU_PCA.txt","r")
for line in fs:
    x=line.split(symb)
    node_mir.append(x[0])
    ft.write(line.strip())
    ft.write("\n")
    l.append(len(x))
fs.close()



fs=open(r"SBERT_embeddings_PCA_AE_BiGRU_PCA_AE_imp.txt","r")
for line in fs:
    x=line.split(symb)
    node_go.append(x[0])
    ft.write(line.strip())
    ft.write("\n")
    l.append(len(x))
fs.close()




fs=open(r"SBERT_embeddings_PCA_AE_BiGRU_PCA_disease.txt","r")
for line in fs:
    x=line.split(symb)
    node_dis.append(x[0])
    ft.write(line.strip())
    ft.write("\n")
    l.append(len(x))
fs.close()



ft.close()
l=list(set(l))
print(l)
print(len(node_mir),len(node_go),len(node_dis))
print(len(node_mir)+len(node_go)+len(node_dis))







