




trials=50
loop=100
symb="`"
mir=[]
go_a=[]
dis=[]
mir_feat=[]
go_feat=[]
dis_feat=[]

fs=open(r"merged_embeddings_mir_go_dis_BiGRU.txt","r")
for line in fs:
    x=line.split(symb)
    if x[0].startswith("hsa-"):
      mir.append(x[0])
      mir_feat.append([float(i) for i in x[1:-1]])
    elif x[0].startswith("GO"):
      go_a.append(x[0])
      go_feat.append([float(i) for i in x[1:-1]])
    else:
      dis.append(x[0])
      dis_feat.append([float(i) for i in x[1:-1]])

fs.close()
print(len(mir),len(go_a),len(dis))
print(mir[0],mir_feat[0])
print(go_a[0],go_feat[0])
print(dis[0],dis_feat[0])

mir_go=[]
mir_mir=[]
mir_dis=[]
ft=open(r"positive_ID_mir_go_dis_whole.txt","r")
for line in ft:
    x=line.split(symb)
    if x[0].startswith("hsa") and x[1].startswith("GO"):
       temp=[]
       temp.append(mir.index(x[0]))
       temp.append(go_a.index(x[1]))
       mir_go.append(temp)
    elif x[0].startswith("hsa") and x[1].startswith("hsa"):
       temp=[]
       temp.append(mir.index(x[0]))
       temp.append(mir.index(x[1]))
       mir_mir.append(temp)
    else:
       temp=[]
       temp.append(mir.index(x[0]))
       temp.append(dis.index(x[1]))
       mir_dis.append(temp)
ft.close()
print(len(mir_go),len(mir_mir),len(mir_dis))

import torch
from torch_geometric.data import HeteroData
import torch_geometric.transforms as T


data = HeteroData()


data['mir'].x = torch.tensor(mir_feat, dtype=torch.float)
data['go'].x = torch.tensor(go_feat, dtype=torch.float)
data['dis'].x=torch.tensor(dis_feat, dtype=torch.float)
data['mir', 'assoc', 'go'].edge_index = torch.tensor(mir_go).t().contiguous()
data['mir', 'assoc', 'mir'].edge_index = torch.tensor(mir_mir).t().contiguous()
data['mir', 'assoc', 'dis'].edge_index = torch.tensor(mir_dis).t().contiguous()



data = T.ToUndirected()(data)

print(data)



import optuna
import torch
import torch.nn.functional as F
import torch_geometric.transforms as T
from torch_geometric.nn import HGTConv
from torch_geometric.data import HeteroData
from torch_geometric.utils import negative_sampling


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
types = [('mir', 'assoc', 'go'), ('mir', 'assoc', 'mir'), ('mir', 'assoc', 'dis')]


class HGT(torch.nn.Module):
    def __init__(self, in_dic, hidden, out, metadata, head=2):
        super().__init__()
        self.hgt = HGTConv(in_channels=in_dic, out_channels=hidden, metadata=metadata, heads=head)
        self.lin = torch.nn.Linear(hidden, out)

    def encode(self, x_dic, index_dic):
        z = self.hgt(x_dic, index_dic)
        return {key: F.relu(self.lin(zz)) for key, zz in z.items()}

    def score(self, z_dic, index, etype):
        src, _, dst = etype
        return (z_dic[src][index[0]] * z_dic[dst][index[1]]).sum(dim=-1)


splitter = T.RandomLinkSplit(num_val=0.2, num_test=0.0, neg_sampling_ratio=0.0, edge_types=types, rev_edge_types=None)
train_data, val_data, _ = splitter(data)
train_data = train_data.to(device)
val_data = val_data.to(device)


def objective(trial):
    hidden = trial.suggest_categorical("hidden", [16, 32, 64])
    head= trial.suggest_categorical("head", [1, 2, 4])
    lr = trial.suggest_float("lr", 1e-4, 1e-2, log=True)
    out = trial.suggest_categorical("out", [16, 32, 64, 128])
    in_dic={}
    for node_type in train_data.node_types:
        in_dic[node_type]=train_data[node_type].x.size(-1)
    print(len(in_dic.keys()))
    model = HGT(in_dic=in_dic, hidden=hidden, out=out, metadata=train_data.metadata(), head=head).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)


    model.train()
    for epoch in range(loop):
        optimizer.zero_grad()
        z= model.encode(train_data.x_dict, train_data.edge_index_dict)
        loss = 0
        for t in types:
            stype, _, dtype = t
            pos = train_data[t].edge_label_index
            neg= negative_sampling(edge_index=pos.cpu(), num_nodes=(train_data[stype].num_nodes, train_data[dtype].num_nodes), num_neg_samples=pos.size(1)).to(device)
            p = model.score(z, pos, t)
            n = model.score(z, neg, t)
            loss += F.binary_cross_entropy_with_logits(p, torch.ones_like(p))
            loss += F.binary_cross_entropy_with_logits(n, torch.zeros_like(n))
        loss.backward()
        optimizer.step()


    model.eval()
    loss = 0
    with torch.no_grad():
        z = model.encode(val_data.x_dict, val_data.edge_index_dict)
        for t in types:
            stype, _, dtype = t
            pos = val_data[t].edge_label_index
            neg = negative_sampling(edge_index=pos.cpu(), num_nodes=(val_data[stype].num_nodes, val_data[dtype].num_nodes), num_neg_samples=pos.size(1)).to(device)
            p= model.score(z, pos, t)
            n= model.score(z, neg, t)
            loss += F.binary_cross_entropy_with_logits(p, torch.ones_like(p))
            loss += F.binary_cross_entropy_with_logits(n, torch.zeros_like(n))
    return loss.item()


study = optuna.create_study(direction="minimize")
study.optimize(objective, n_trials=trials)
param= study.best_params


data = data.to(device)

in_dic={}
for node_type in data.node_types:
    in_dic[node_type]=data[node_type].x.size(-1)
print(len(in_dic.keys()))
model = HGT(in_dic=in_dic, hidden=param["hidden"], out=param["out"], metadata=data.metadata(), head=param["head"]).to(device)
model.eval()
with torch.no_grad():
    z = model.encode(data.x_dict, data.edge_index_dict)
    hard = {}
    for t in types:
        stype, _, dtype = t
        neg_edges = negative_sampling(edge_index=data[t].edge_index.cpu(), num_nodes=(data[stype].num_nodes, data[dtype].num_nodes), num_neg_samples=data[t].edge_index.size(1) * 5).to(device)
        neg= model.score(z, neg_edges, t)
        thresh = torch.quantile(neg, 0.8)
        temp = neg_edges[:, neg>= thresh]
        hard[t] = temp.t().cpu().tolist()

df = study.trials_dataframe()
df.to_csv("optuna_trials_log_HGT.csv", index=False)

count=0
c=0
d=0
e=0
hard_neg=[]
fa=open(r"hard_neg_mgd_BiGRU.txt","w")
for neg_edge in hard[types[0]]:
    count+=1
    [aa,bb]=neg_edge
    s=mir[aa]+"`"+go_a[bb]+"`"
    s=s.strip()
    hard_neg.append(s)
    fa.write(s)
    fa.write("\n")
    if count<=10:
       print(s)

for neg_edge in hard[types[1]]:
    count+=1
    [aa,bb]=neg_edge
    s=mir[aa]+"`"+mir[bb]+"`"
    s=s.strip()
    hard_neg.append(s)
    fa.write(s)
    fa.write("\n")
    if count<=10:
       print(s)

for neg_edge in hard[types[2]]:
    count+=1
    [aa,bb]=neg_edge
    s=mir[aa]+"`"+dis[bb]+"`"
    s=s.strip()
    hard_neg.append(s)
    fa.write(s)
    fa.write("\n")
    if count<=10:
       print(s)


fa.close()
print(count,c,d,e)
hard_neg=list(set(hard_neg))
print(len(hard_neg))

count=0
test=[]
miRNA=[]
ft=open(r"pos_test_data.txt","r")
for line in ft:
    count+=1
    x=line.split("`")
    miRNA.append(x[0])
    test.append(line.strip())
ft.close()
miRNA=list(set(miRNA))
print(len(miRNA))




from goatools import obo_parser
import os


obo_file = 'go-basic.obo'
go = obo_parser.GODag(obo_file)


bp_terms = []
for go_id, term in go.items():
    if term.namespace == 'biological_process':
        bp_terms.append(go_id)

print(len(bp_terms))


for t in bp_terms[:10]:
    print(t)

count=0
c=0
pos=[]
fneg=open(r"negative_ID_mir_go_dis_whole_modified.txt","w")
fpos=open(r"positive_ID_mir_go_dis_whole_modified.txt","w")
ft=open(r"total_ID_mgd_BiGRU_jaccard.txt","w")
fv=open(r"labels_total_ID_mgd_BiGRU_jaccard.txt","w")
fs=open(r"positive_ID_mir_go_dis_whole.txt","r")
for line in fs:
    count+=1
    x=line.split("`")
    if x[0].strip() in miRNA and x[1].strip() in bp_terms:
       continue
    c+=1
    pos.append(line.strip())
    if x[0].startswith("hsa") and x[1].startswith("hsa"):
       t=x[1].strip()+"`"+x[0].strip()+"`"
       t=t.strip()
       pos.append(t)
    ft.write(line.strip())
    ft.write("\n")
    fpos.write(line.strip())
    fpos.write("\n")
    fv.write("1")
    fv.write("\n")
fs.close()
fpos.close()
print(count,c)



hard_neg=[]
fs=open(r"hard_neg_mgd_BiGRU.txt","r")
for line in fs:
    hard_neg.append(line.strip())
fs.close()

hard_neg=set(hard_neg).difference(pos)
hard_neg=list(hard_neg)

for line in hard_neg:
    count+=1
    x=line.split("`")
    if x[0] in miRNA and x[1].strip() in bp_terms:
       continue
    c+=1
    if x[0] in miRNA and x[1] in miRNA:
       print(line)
    ft.write(line.strip())
    ft.write("\n")
    fneg.write(line.strip())
    fneg.write("\n")
    fv.write("0")
    fv.write("\n")
fs.close()
fneg.close()
ft.close()
fv.close()
print(count,c)
