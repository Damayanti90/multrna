

count=0
enriched=[]
import re
fs=open(r"analysis_pathway.txt","r")
for line in fs:
    count+=1
    if count<=60:
       print(count,line)
    if count>=13:
       x=re.split("\t",line)
       y=x[0].split("(")
       if float(x[7].strip())<=0.05:
          enriched.append(y[-1][:-1])
fs.close()
print(count,len(enriched))

len(enriched)

import re
count=0
pcos_pathways=[]
fs=open(r"PCOS_pathways_CTD.tsv","r")
for line in fs:
    count+=1
    x=re.split("\t",line)
    if count<=10:
       print(line)
       print(x[3])
       print(x[3][6:].strip())
    if count==1:
       continue
    if x[3].startswith("REACT:"):
       pcos_pathways.append(x[3][6:].strip())
fs.close()
pcos_pathways=list(set(pcos_pathways))
print(count,len(pcos_pathways))

import re
count=0
anov_pathways=[]
fs=open(r"Anovulation_pathways_CTD.tsv","r")
for line in fs:
    count+=1
    x=re.split("\t",line)
    if count<=10:
       print(line)
       print(x[3])
       print(x[3][6:].strip())
    if count==1:
       continue
    if x[3].startswith("REACT:"):
       anov_pathways.append(x[3][6:].strip())
fs.close()
anov_pathways=list(set(anov_pathways))
print(count,len(anov_pathways))

import re
count=0
ins_pathways=[]
fs=open(r"Diabetes_II_pathways_CTD.tsv","r")
for line in fs:
    count+=1
    x=re.split("\t",line)
    if count<=10:
       print(line)
       print(x[3])
       print(x[3][6:].strip())
    if count==1:
       continue
    if x[3].startswith("REACT:"):
       ins_pathways.append(x[3][6:].strip())
fs.close()
ins_pathways=list(set(ins_pathways))
print(count,len(ins_pathways))

import re
count=0
andro_pathways=[]
fs=open(r"Hyperandrogenism_pathways_CTD.tsv","r")
for line in fs:
    count+=1
    x=re.split("\t",line)
    if count<=10:
       print(line)
       print(x[3])
       print(x[3][6:].strip())
    if count==1:
       continue
    if x[3].startswith("REACT:"):
       andro_pathways.append(x[3][6:].strip())
fs.close()
andro_pathways=list(set(andro_pathways))
print(count,len(andro_pathways))

x=set(enriched). intersection (set(pcos_pathways))
print(len(pcos_pathways),"PCOS",len(x))

temp=set(pcos_pathways). intersection (set(anov_pathways))
x=set(temp). intersection (set(enriched))
print(len(temp),"PCOS and anovulation",len(x))

temp=set(pcos_pathways). intersection (set(ins_pathways))
x=set(temp). intersection (set(enriched))
print(len(temp),"PCOS and insulin resistance",len(x))

temp=set(pcos_pathways). intersection (set(andro_pathways))
x=set(temp). intersection (set(enriched))
print(len(temp),"PCOS and hyperandrogenism",len(x))
