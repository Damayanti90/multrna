




trials=50
folds=10
iterations=10
loop=100
import numpy as np

import pandas as pd
import pickle
from sklearn.preprocessing import Normalizer

df = pd.read_csv(r"Rinalmo_embeddings.txt", sep="`", header=None)
x = df.iloc[:, 1:-1].values
print(df.head().to_string())


from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
x= sc.fit_transform(x)


from sklearn.decomposition import PCA
pca = PCA(0.99)



unpickled_df = pca.fit_transform(x)
explained_variance = pca.explained_variance_ratio_


print(explained_variance)
print(unpickled_df)
print(type(unpickled_df))
print(unpickled_df.shape)





mother=[]
x=df.values.tolist()
y=unpickled_df.tolist()
print(x[0])
print (len(x),len(x[0]))
print(y[0])
print(len(y),len(y[0]))
for i,j in zip(x,y):
    son=[]
    son.append(i[0])

    for k in j:
        son.append(k)
    mother.append(son)
print(mother[0])
print(len(mother),len(mother[0]))
dh=pd.DataFrame(mother)
print(dh)


symb="`"
count=0

fp=open(r"Rinalmo_embeddings_PCA.txt","w")



for i in mother:
    count+=1
    st=""
    for j in i:
        st=st+str(j)+symb
    if count<=10:
       print(st.strip())
    fp.write(st.strip())
    fp.write("\n")
    
fp.close()
print(count)

count=0
ids=[]
feat_lst=[]
symb="`"
fs=open(r"Rinalmo_embeddings_PCA.txt","r")
for line in fs:
    count+=1
    if count<=10:
       print(line)
    x=line.split(symb)    
    ids.append(x[0])
    feat_lst.append(x[1:-1])
fs.close()
print(len(ids),len(feat_lst))
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import TensorDataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
import optuna
from optuna.pruners import MedianPruner, PatientPruner
import numpy as np


input=len(feat_lst[0])
data=np.array(feat_lst).astype(np.float32)
scale = MinMaxScaler()
data = scale.fit_transform(data)
X_train, X_val = train_test_split(data, test_size=0.1, random_state=42)
train_data= TensorDataset(torch.from_numpy(X_train))
val_data= TensorDataset(torch.from_numpy(X_val))


class AE(nn.Module):
    def __init__(self, orig, inter, latent):
        super(AE, self).__init__()


        self.encoder = nn.Sequential(
            nn.Linear(orig, inter),
            nn.ReLU(),
            nn.Linear(inter, inter // 2),
            nn.ReLU(),
            nn.Linear(inter // 2, latent)
        )


        self.decoder = nn.Sequential(
            nn.Linear(latent, inter// 2),
            nn.ReLU(),
            nn.Linear(inter // 2, inter),
            nn.ReLU(),
            nn.Linear(inter, orig),
            nn.Sigmoid()
        )

    def forward(self, x):
        z = self.encoder(x)
        recon= self.decoder(z)
        return recon, z

    def encode(self, x):
        return self.encoder(x)


def train_func(model, train_load, opt):
    model.train()
    tot_loss= 0
    for bx, in train_load:
        opt.zero_grad()
        recon, _ = model(bx)
        loss = F.mse_loss(recon, bx, reduction='mean')
        loss.backward()
        opt.step()
        tot_loss += loss.item()
    return tot_loss/ len(train_load)

def val_func(model, val_load):
    model.eval()
    tot_loss = 0
    with torch.no_grad():
        for bx, in val_load:
            recon, _ = model(bx)
            loss= F.mse_loss(recon, bx, reduction='mean')
            tot_loss += loss.item()
    return tot_loss / len(val_load)

def objective(trial):
    latent= trial.suggest_categorical('latent_dim', [64,128])
    inter= trial.suggest_int('intermediate_dim', 128, 512)
    lr = trial.suggest_float('learning_rate', 1e-5, 1e-2, log=True)
    batch= trial.suggest_categorical('batch_size', [32, 64, 128, 256])
    epoch = trial.suggest_int('epochs', 30, 100)

    train_load = DataLoader(train_data, batch_size=batch, shuffle=True)
    val_load= DataLoader(val_data, batch_size=batch)

    model = AE(orig=input, inter=inter, latent=latent)
    opt = optim.Adam(model.parameters(), lr=lr)

    for ep in range(epoch):
        trainl_loss = train_func(model, train_load, opt)
        val_loss = val_func(model, val_load)

        trial.report(val_loss, ep)
        if trial.should_prune():
            raise optuna.exceptions.TrialPruned()

    return val_loss

if __name__ == "__main__":
    pr= PatientPruner(wrapped_pruner=MedianPruner(n_startup_trials=5, n_warmup_steps=5), patience=5)
    study = optuna.create_study(direction='minimize', pruner=pr)
    study.optimize(objective, n_trials=trials, show_progress_bar=True)

    best_par = study.best_params
    print("\nBest hyp", best_par)


    fmodel= AE(input, best_par['intermediate_dim'], best_par['latent_dim'])
    fopt = optim.Adam(fmodel.parameters(), lr=best_par['learning_rate'])

    full_load = DataLoader(TensorDataset(torch.from_numpy(data)),
                             batch_size=best_par['batch_size'], shuffle=True)

    for epoch in range(best_par['epochs']):
        train_func(fmodel, full_load, fopt)


    fmodel.eval()
    with torch.no_grad():
        full_data = torch.from_numpy(data)
        compr = fmodel.encode(full_data).numpy()
        print("\nCompressed Shape:", compr.shape)

count=0
symb="`"
fet_lst=[]
fs=open(r"Rinalmo_embeddings_PCA_AE.txt","w")
for id,line in zip(ids,compr):
    count+=1   
    s=""
    s+=str(id)+symb
    t=""
    for i in range(len(line)):
        s+=str(line[i])+symb
        t+=str(line[i])+symb
    s=s.strip()
    t=t.strip()
    fet_lst.append(t)
    fs.write(s)
    fs.write("\n")
    if count<=10:
       print(s)
fet_lst=list(set(fet_lst))
print(count,len(fet_lst))
fs.close()









df = study.trials_dataframe()
df.to_csv("optuna_trials_log_Rinalmo_embeddings_AE.csv", index=False)

embeddings=[]
id_lst=[]
count=0
l=[]
fs=open(r"Rinalmo_embeddings_PCA_AE.txt","r")
for line in fs:
    count+=1
    x=line.split("`")
    l.append(len(x))
    id_lst.append(x[0])
    embeddings.append([float(i) for i in x[1:-1]])
    if count<=10:
       print(line)
fs.close()
print(count)
l=list(set(l))
embed_length=l[0]-2
print(len(id_lst),len(embeddings[0]),l,embed_length)

import torch
import torch.nn as nn
import torch.optim as optim
import optuna
from torch.utils.data import TensorDataset, DataLoader

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(device)
temp= torch.tensor(embeddings, dtype=torch.float32).unsqueeze(-1)
ts= int(0.8 * len(temp))
vs = len(temp) - ts
whole= TensorDataset(temp)
train, test= torch.utils.data.random_split(whole, [ts, vs])
train_l = DataLoader(train, batch_size=16, shuffle=True)
val_l= DataLoader(test, batch_size=16, shuffle=False)
full_l=DataLoader(whole,batch_size=16,shuffle=False)




class BiGRU(nn.Module):
    def __init__(self, input=1, hidden=64, layer=2):
        super().__init__()
        self.bigru = nn.GRU(input_size=input, hidden_size=hidden, num_layers=layer, batch_first=True, bidirectional=True)
        self.out = nn.Linear(hidden * 2, input)

    def forward(self, x):
        out, _ = self.bigru(x)
        return self.out(out)



def objective(trial):
    hidden = trial.suggest_categorical("hidden", [32, 64, 128])
    layer= trial.suggest_int("layer", 1, 3)
    lr = trial.suggest_float("lr", 1e-4, 1e-2, log=True)
    model = BiGRU(input=1, hidden=hidden, layer=layer).to(device)
    loss = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)
    model.train()
    for batch, (batch_x,) in enumerate(train_l):
        batch_x = batch_x.to(device)
        optimizer.zero_grad()
        los = loss(model(batch_x), batch_x)
        los.backward()
        optimizer.step()
        if batch > 15: break
    model.eval()
    los = 0.0
    with torch.no_grad():
        for (batch_x,) in val_l:
            batch_x = batch_x.to(device)
            los += loss(model(batch_x), batch_x).item()
    return los / len(val_l)

optuna.logging.set_verbosity(optuna.logging.INFO)
study = optuna.create_study(direction="minimize")
study.optimize(objective, n_trials=trials)
param = study.best_params
print(param)


model = BiGRU(input=1,hidden=param["hidden"],layer=param["layer"]).to(device)

optimizer = optim.Adam(model.parameters(), lr=param["lr"])
loss = nn.MSELoss()

model.train()
for epoch in range(loop):
    print(epoch)
    for (batch_x,) in train_l:
        batch_x = batch_x.to(device)
        optimizer.zero_grad()
        los = loss(model(batch_x), batch_x)
        los.backward()
        optimizer.step()

import torch
refined = []


model.eval()
with torch.no_grad():
    for batch in full_l:
        batch = batch[0].to(device)
        #print(len(batch))
        temp= model(batch)
        refined.append(temp.cpu())
refined_emb = torch.cat(refined, dim=0)


print(len(refined_emb),list(refined_emb.squeeze(-1).shape))
print(refined_emb[0, :5,0].cpu().numpy())








print(len(refined_emb))

l=[]

ft=open(r"Rinalmo_embeddings_PCA_AE_BiGRU.txt","w")
for i in range(len(refined_emb)):
#for i in range(10):
    temp=refined_emb[i,:,0]
    #temp=temp.to(device).numpy()
    #if device=="cpu":
    temp=temp.cpu().numpy()
    temp=[str(float(str(t))) for t in temp]
    s=id_lst[i]+"`"+"`".join(temp)+"`"
    if i<=10:
       print(s)
    ft.write(s)
    ft.write("\n")
    fgh=s.split("`")
    l.append(len(fgh))
ft.close()
l=list(set(l))
print(l)




df = study.trials_dataframe()
df.to_csv("optuna_trials_log_Rinalmo_embeddings_AE_BiGRU.csv", index=False)

import numpy as np

import pandas as pd
import pickle
from sklearn.preprocessing import Normalizer


df=pd.read_csv(r"Rinalmo_embeddings_PCA_AE_BiGRU.txt",sep="`",header=None)
x = df.iloc[:, 1:-1].values


print(df.head().to_string())


from sklearn.preprocessing import StandardScaler
sc = StandardScaler()

x= sc.fit_transform(x)


from sklearn.decomposition import PCA
pca=PCA(n_components=32)



unpickled_df = pca.fit_transform(x)
"""
from sklearn.decomposition import PCA

max_components = min(32, x.shape[0], x.shape[1])
pca = PCA(n_components=max_components)

unpickled_df = pca.fit_transform(x)
"""


explained_variance = pca.explained_variance_ratio_


print(explained_variance)

print(unpickled_df)
print(type(unpickled_df))
print(unpickled_df.shape)


cumulative_variance = np.sum(explained_variance)
print("Cumulative explained variance:", cumulative_variance)

mother=[]
x=df.values.tolist()
y=unpickled_df.tolist()
print(x[0])
print (len(x),len(x[0]))
print(y[0])
print(len(y),len(y[0]))
for i,j in zip(x,y):
    son=[]
    son.append(i[0])

    for k in j:
        son.append(k)
    mother.append(son)
print(mother[0])
print(len(mother),len(mother[0]))
dh=pd.DataFrame(mother)
print(dh)


symb="`"
count=0

fp=open(r"Rinalmo_embeddings_PCA_AE_BiGRU_PCA.txt","w")


for i in mother:
    count+=1
    st=""
    for j in i:
        st=st+str(j)+symb
    if count<=10:
       print(st.strip())
    fp.write(st.strip())
    fp.write("\n")
    
fp.close()
print(count)
