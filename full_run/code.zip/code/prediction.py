

count=0
c=0
positive_scores=[]
thresh=0.7
fa=open(r"result_test_data_lightGBM_merged.txt","r")
for line in fa:
    count+=1
    if count<=10:
       print(line)

    x=line.split("`")
    if float(x[4].strip())>=thresh:
       c+=1

    positive_scores.append(float(x[4]))

fa.close()

print(count,c,c/count)

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns





count=0
c=0
fs=open(r"predicted_associations.txt","w")
fa=open(r"result_blind_data_lightGBM_merged.txt","r")
for line in fa:
    count+=1
    if count<=10:
       print(line)
    x=line.split("`")
    if float(x[4].strip())>=thresh:
       c+=1
       fs.write(line.strip())
       fs.write("\n")
    
fa.close()
fs.close()
print(count,c)
