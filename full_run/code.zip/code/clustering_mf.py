

from goatools import obo_parser
import os


obo_file = 'go-basic.obo'
go = obo_parser.GODag(obo_file)
bp_terms = []
for go_id, term in go.items():
    #if term.namespace == 'biological_process':
    if term.namespace == 'molecular_function':
        bp_terms.append(go_id)
print("mf terms",len(bp_terms))
for t in bp_terms[:10]:
    print(t)



def leaf(file_path):
    all_terms = set()
    parent_terms = set()
    is_obsolete = False
    current_term = None
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()            
            if line == '[Term]':
                if current_term and not is_obsolete:
                    all_terms.add(current_term)
                current_term = None
                is_obsolete = False
            elif line == '[Typedef]' or line == '[Instance]':
                current_term = None  
            elif line.startswith('id: ') and line.startswith('id: GO:'):
                #current_term = line[4:].split()[0].strip()
                temp=line[4:].split()
                current_term=temp[0].strip()
            elif line.startswith('is_a: ') and current_term:                
                #parent_id = line[6:].split('!')[0].strip().split()[0]
                temp=line[6:].split('!')
                tempa=temp[0].strip().split()
                #parent_id=tempa[0]
                #parent_terms.add(parent_id)
                parent_terms.add(tempa[0])
            elif line == 'is_obsolete: true':
                is_obsolete = True        
        if current_term and not is_obsolete:
            all_terms.add(current_term)    
    leaves = sorted(list(all_terms - parent_terms))
    return leaves


leaves = leaf('go-basic.obo')
print("leaves", leaves)

go_active=[]
fs=open(r"go_genes.txt","r")
for line in fs:
    x=line.split("`")
    go_active.append(x[0])
fs.close()
print(len(go_active))

active_leaves=set(go_active). intersection (set(leaves))
bp_active_leaves=set(bp_terms). intersection (set(active_leaves))
bp_active_leaves=list(bp_active_leaves)
print(len(bp_active_leaves))



from pygosemsim import similarity
from pygosemsim import graph


G = graph.from_obo(r"go-basic.obo")

bp_G=[i for i in bp_active_leaves if i in G.nodes()]
print(len(bp_G))

count=0
bp=[]
symb="`"
ft=open(r"mf_embeddings.txt","w")
fs=open(r"merged_embeddings_mir_go_dis_BiGRU.txt","r")
for line in fs:
    count+=1
    x=line.split(symb)
    if x[0] in bp_G:
       bp.append(x[0])
       ft.write(line.strip())
       ft.write("\n")
fs.close()
ft.close()


import numpy as np
import numpy as np
import pandas as pd
from scipy.cluster.hierarchy import linkage, dendrogram, cut_tree
from scipy.spatial.distance import squareform
from sklearn.cluster import AgglomerativeClustering
import networkx as nx

def cluster(sim_mat,thresh=0.5):


    
    dist_mat = 1 - sim_mat
    np.fill_diagonal(dist_mat, 0)    
    mask = dist_mat < 0
    neg_check = np.any(mask)
    if neg_check:    
         row, col = np.where(mask)   
         tot_neg = len(row)   
         for i in range(tot_neg):
             r = row[i]
             c = col[i]
             dist_mat[r, c] = 0  
    rows = len(dist_mat)
    cols = len(dist_mat[0])
    for r in range(rows):  
    	for c in range(cols):
        	if dist_mat[r][c] < 0:          
            		dist_mat[r][c] = 0
    cut = 1 - thresh
    clustering = AgglomerativeClustering(n_clusters=None, metric='precomputed', linkage='average', distance_threshold=cut)  
    clustering.fit(dist_mat)   
    return clustering.labels_
    

def sim_mat(go_terms):




    sim_matrix = pd.DataFrame(index=go_terms, columns=go_terms, dtype=float)
    count=0   
    for term1 in go_terms:
        count+=1
        if count%10==0:
           print(count," go terms covered out of ",len(go_terms))
        for term2 in go_terms:           
              score = similarity.wang(G, term1, term2)
              sim_matrix.loc[term1, term2] = score
            


    return sim_matrix

import numpy as np

import pandas as pd
import pickle
from sklearn.preprocessing import Normalizer

df = pd.read_csv(r"mf_embeddings.txt", sep="`", header=None)

x = df.iloc[:, 1:-1].values


print(df.head().to_string())


from sklearn.preprocessing import StandardScaler
sc = StandardScaler()

x= sc.fit_transform(x)


from sklearn.decomposition import PCA
pca=PCA(n_components=2)


unpickled_df = pca.fit_transform(x)
explained_variance = pca.explained_variance_ratio_


print(explained_variance)

print(unpickled_df)
print(type(unpickled_df))
print(unpickled_df.shape)





mother=[]
x=df.values.tolist()
y=unpickled_df.tolist()
print(x[0])
print (len(x),len(x[0]))
print(y[0])
print(len(y),len(y[0]))
for i,j in zip(x,y):
    son=[]
    son.append(i[0])

    for k in j:
        son.append(k)
    mother.append(son)
print(mother[0])
print(len(mother),len(mother[0]))
dh=pd.DataFrame(mother)
print(dh)


symb="`"
count=0

fp=open(r"2D_mf_embeddings.txt","w")



for i in mother:
    count+=1
    st=""
    for j in i:
        st=st+str(j)+symb
    if count<=10:
       print(st.strip())
    fp.write(st.strip())
    fp.write("\n")
    #count+=1
fp.close()
print(count)

go_coords={}
fp=open(r"2D_mf_embeddings.txt","r")
for line in fp:
    x=line.split("`")
    go_coords[x[0]]=[round(float(x[1]),4),round(float(x[2]),4)]
fp.close()
print(len(go_coords.keys()))





def inertia(X, labels):
    
    unique_labels = np.unique(labels)
    inertia = 0
    for label in unique_labels:
        if label == -1:
            continue
        clus_points = X[labels == label]
        if clus_points.size > 0:
            centroid = np.mean(clus_points, axis=0)
            inertia += np.sum((clus_points - centroid)**2)
    return inertia



go_terms=[aa for aa in bp_G]

data=sim_mat(go_terms)

a=data.to_numpy()

import numpy as np
import matplotlib.pyplot as plt
from kneed import KneeLocator
symb="`"
ft=open(r"threshold_stats_mf.txt","w")
thresholds = np.linspace(0.1, 0.5, 50)
inertias = []
num_clusters_list = []
t=""
for similarity_threshold in thresholds:
        s=""      
        labels = cluster(a, thresh=similarity_threshold)
        n_clusters = len(np.unique(labels))
        num_clusters_list.append(n_clusters)      
        temp=[]
        for g in go_terms:
            temp.append(go_coords[g])
        temp=np.array(temp)
        inert = inertia(temp, labels)
        s+="threshold="+str(similarity_threshold)+",WCSS="+str(inert)+", #clusters="+str(n_clusters)+symb
        inertias.append(inert)
        s=s.strip()
        ft.write(s)
        ft.write("\n")
        print(s)
kn = KneeLocator(thresholds, inertias, curve='convex', direction='decreasing', S=1.0)
opt_thresh = kn.elbow
"""
plt.figure(figsize=(10, 6))
plt.plot(thresholds, inertias, marker='o')
plt.title('Elbow Method for Agglomerative Clustering Threshold')
plt.xlabel('Distance Threshold')
plt.ylabel('Inertia (WCSS)')
plt.grid(True)
plt.show()


plt.figure(figsize=(10, 6))
plt.plot(thresholds, num_clusters_list, marker='o', color='red')
plt.title('Number of Clusters vs Distance Threshold')
plt.xlabel('Distance Threshold')
plt.ylabel('Number of Clusters')
plt.grid(True)
plt.show()
"""

if opt_thresh is not None:
       
       idx = list(thresholds).index(opt_thresh)
       opt_clus = num_clusters_list[idx]

       print("distance ",opt_thresh)
       print("cluster ",opt_clus)
       t+="threshold="+str(opt_thresh)+", WCSS="+str(inertias[idx])+",#clusters="+str(opt_clus)+symb
else:
       print("problem")
       t+="threshold=NA,WCSS=NA,#clusters=NA`"
t=t.strip()
print(t)
ft.close()

ft=open(r"mf_cluster_labels.txt","w")
labels = cluster(a, thresh=opt_thresh)
for i in range(len(go_terms)):
    print(go_terms[i],labels[i])
    s=str(go_terms[i])+"`"+str(labels[i])+"`"
    ft.write(s)
    ft.write("\n")
    print(s)
ft.close()

unique_labels=list(set(labels))
print(len(unique_labels))

go_terms=[aa for aa in bp_G]
count=0
symb="`"
pred_data=[]
fs=open(r"predicted_associations.txt","r")
for line in fs:
    count+=1
    x=line.split(symb)
    
    if x[1] not in go_terms:
       continue
    
    s=x[0]+symb+x[1]+symb
    s=s.strip()
    pred_data.append(s)
    if count<=10:
       print(line)
fs.close()
print(count,len(pred_data))

count=0
symb="`"
existing_data=[]
fs=open(r"positive_ID_mir_go_dis_whole.txt","r")
for line in fs:
    count+=1
    x=line.split(symb)
    if x[1] not in go_terms:
       continue
    if x[0].startswith("hsa-miR-155-5p")==0:
      continue
    s=x[0]+symb+x[1]+symb
    s=s.strip()
    existing_data.append(s)
    if count<=10:
       print(line)
fs.close()
print(len(existing_data))

symb="`"
l=[]
node_mir=[]
ft=open(r"merged_embeddings_mir_go_dis_BiGRU.txt","r")
for line in ft:
    x=line.split(symb)
    if x[0].startswith("hsa-miR-155-5p"):
       print(x[0])
       node_mir.append(x[0])
    
ft.close()

pred_data=list(pred_data)



tot_data=pred_data
len(tot_data)

mir_dic={}
for line in tot_data:
    x=line.split(symb)
    if x[0] not in mir_dic.keys():
       mir_dic[x[0]]=[x[1]]
    else:
       temp=mir_dic[x[0]]
       temp.append(x[1])
       mir_dic[x[0]]=temp
print(len(mir_dic.keys()))

go_cluster={}
ft=open(r"mf_cluster_labels.txt","r")
for line in ft:
    x=line.split(symb)
    go_cluster[x[0]]=int(x[1])
ft.close()
print(len(go_cluster.keys()))

go_lst=mir_dic['hsa-miR-155-5p']
clus=[]
for go in go_lst:
    if go in go_cluster.keys():
       clus.append(go_cluster[go])
clus_unique=list(set(clus))
print(len(clus_unique))

from collections import Counter


frequencies = Counter(clus)


cc=0
for c in clus_unique:
    if frequencies[c]>=10:
       cc+=1
       print(c,frequencies[c])
print("10 or more bp associations to",cc,"clusters")

mir_clus={}
fa=open(r"mf_associations.txt","w")
for mir in node_mir:
    go_lst=mir_dic[mir]
    clus=[]
    for go in go_lst:
        if go in go_cluster.keys():
           clus.append(go_cluster[go])
    clus_unique=list(set(clus))
    mir_clus[mir]=clus
    s=mir+"`"+",".join([str(i) for i in clus])+"`"
    print(s)
    fa.write(s)
    fa.write("\n")
    if len(clus_unique)>1:
       print(clus_unique)
       print(mir," possibly multifunctional from mf side")
fa.close()
print(len(mir_clus.keys()))


